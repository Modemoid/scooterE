/*
 * TermoStat.c
 *
 * Created: 02.03.2015 21:55:31
 *  Author: kartsev
 */ 

#define F_CPU 4800000UL

#include <avr/io.h>
#include <avr/delay.h>
//#define F_CPU 9600000UL

// --- Configuration for OneWire
#define ONEWIRE_PORTReg     PORTB
#define ONEWIRE_DDRReg      DDRB
#define ONEWIRE_PINReg      PINB
#define ONEWIRE_PIN         PB0

// --- Configure heater
#define Relay_PORTReg         PORTB
#define Relay_DDRReg          DDRB
#define Relay_PIN             PB1

// --- Configure cooler
#define Relay1_PORTReg         PORTB
#define Relay1_DDRReg          DDRB
#define Relay1_PIN             PB2



// - Configure for alarm
#define ALARM_PORTReg               PORTB
#define ALARM_DDRReg                DDRB
#define ALARM_PIN                   PB3 //Hot

#define ALARM1_PORTReg               PORTB
#define ALARM1_DDRReg                DDRB
#define ALARM1_PIN                   PB4 //cold

//#define ALARM_ON_MAX_ERRORS         16
#define ALARM_ON_to_cold    75
#define ALARM_ON_to_hot    85



// - Turn on alarm
#define Alarm_On    ALARM_PORTReg |= (1<<ALARM_PIN);
// - Turn off alarm
#define Alarm_Off   ALARM_PORTReg &= ~(1<<ALARM_PIN);

// - Turn on alarm1
#define Alarm1_On    ALARM1_PORTReg |= (1<<ALARM1_PIN);
// - Turn off alarm1
#define Alarm1_Off   ALARM1_PORTReg &= ~(1<<ALARM1_PIN);

// - Turn on relay
#define Relay_On    Relay_PORTReg |= (1<<Relay_PIN);
// - Turn off relay
#define Relay_Off   Relay_PORTReg &= ~(1<<Relay_PIN);

// - Turn on relay1
#define Relay1_On    Relay1_PORTReg |= (1<<Relay1_PIN);
// - Turn off relay1
#define Relay1_Off   Relay1_PORTReg &= ~(1<<Relay1_PIN);

uint8_t ErrorCount  = 0;
uint16_t Temp = 0;

//! Main function
int main() 
{
	
	// - Configure alarm pin
	ALARM_DDRReg |= ( 1 << ALARM_PIN );
	ALARM1_DDRReg |= ( 1 << ALARM1_PIN );
	// - Configure PWM pin
	Relay_DDRReg |= ( 1 << Relay_PIN );
	Relay1_DDRReg |= ( 1 << Relay1_PIN );


	// - Allow interrupts
	//sei();
	
	
	// - Main loop
	while( 1 )
	{
		    
			Alarm_On;
			_delay_ms(100);
			//Relay_On;
			Alarm_Off;
			_delay_ms(50);
			Alarm_On;
			_delay_ms(50);
			//Relay_On;
			Alarm_Off;
			_delay_ms(100);
			//Relay_Off;
	}
}
		
